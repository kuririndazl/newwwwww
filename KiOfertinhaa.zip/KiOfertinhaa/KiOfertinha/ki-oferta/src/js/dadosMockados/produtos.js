const produtos = [
    {
        id:1,
        nome:"Café Pilão",
        preco:10.99,
        img: `${import.meta.env.BASE_URL}img/pilao.jpg`,
        categoria: "bebidas"
    },
    {
        id:2,
        nome:"café três corações",
        preco:8.99,
        img: `${import.meta.env.BASE_URL}img/coracoes.png`,
        categoria: "bebidas"
    }, 
    {
        id:3,
        nome:"café expresso",
        preco:12.99,
        img: `${import.meta.env.BASE_URL}img/expresso.jpg`,
        categoria: "bebidas"
    },
    {
        id:4,
        nome:"café Melitta",
        preco:15.99,
        img: `${import.meta.env.BASE_URL}img/melita.jpg`,
        categoria: "bebidas"
    },
    {
        id:5,
        nome:"Desinfetante Pinho Sol",
        preco:6.55,
        img: `${import.meta.env.BASE_URL}img/sol.jpg`,
        categoria: "limpeza"
    },
    {
        id:6,
        nome:"Sabonete Protex Ômega",
        preco:21.90,
        img: `${import.meta.env.BASE_URL}img/omega.jpg`,
        categoria: "limpeza"
    },
    {
        id:7,
        nome:"Lava Roupas em Pó Brilhante",
        preco:38.90,
        img: `${import.meta.env.BASE_URL}img/brilhante.jpg`,
        categoria: "limpeza"
    },
    {
        id:8,
        nome:"Arroz Camil",
        preco:21.90,
        img: `${import.meta.env.BASE_URL}img/camil.jpg`,
        categoria: "mercearia"
    },
    {
        id:9,
        nome:"Feijão Preto Camil",
        preco:6.75,
        img: `${import.meta.env.BASE_URL}img/preto.jpg`,
        categoria: "mercearia"
    },
    {
        id:10,
        nome:"Pão Panco",
        preco:8.99,
        img: `${import.meta.env.BASE_URL}img/forma.jpg`,
        categoria: "mercearia"
    },
    {
        id:11,
        nome:"Carne Bovina Acem",
        preco:51.48,
        img: `${import.meta.env.BASE_URL}img/bovina.jpg`,
        categoria: "carnes"
    },
    {
        id:12,
        nome:"Picanha Fatiada",
        preco:15.87,
        img: `${import.meta.env.BASE_URL}img/picanha.jpg`,
        categoria: "carnes"
    },
    {
        id:13,
        nome:"Pernil Suino Sadia",
        preco:38.85,
        img: `${import.meta.env.BASE_URL}img/suino.jpg`,
        categoria: "carnes"
    },
    {
        id:14,
        nome:"Escova de Dente Colgate",
        preco:10.90,
        img: `${import.meta.env.BASE_URL}img/colgate.png`,
        categoria: "higiene"
    },
    {
        id:15,
        nome:"Sabonete Nivea Leite",
        preco:1.99,
        img: `${import.meta.env.BASE_URL}img/leite.jpg`,
        categoria: "higiene"
    },
    {
        id:16,
        nome:"Creme Dental Colgate",
        preco:4.65,
        img: "",
        categoria: "higiene"
    }
]

export default produtos