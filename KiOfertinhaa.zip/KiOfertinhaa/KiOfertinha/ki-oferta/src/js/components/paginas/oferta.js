function oferta(app){
    app.innerHTML = `
    <div>
        <h1>Oferta</h1>
    </div>
    `
}

export default{
    url: "#oferta",
    label: "Oferta",
    icon: "badge-dollar-sign",
    pagina: oferta
}