function carrinho(app){
    app.innerHTML = `
    <div>
        <h1>Carrinho</h1>
    </div>
    `
}

export default{
    url: "#carrinho",
    label: "Carrinho",
    icon: "shopping-cart",
    pagina: carrinho
}