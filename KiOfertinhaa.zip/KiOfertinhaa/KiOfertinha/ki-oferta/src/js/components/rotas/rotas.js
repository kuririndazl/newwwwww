import home from '../paginas/home.js'
import Oferta from '../paginas/Oferta.js'
import pesquisa from '../paginas/pesquisa.js'
import carrinho from '../paginas/carrinho.js'




const rotas = [
    pesquisa,
    home,
    Oferta,
    carrinho,
    

]

export { rotas }